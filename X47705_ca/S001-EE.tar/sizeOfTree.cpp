#include "sizeOfTree.hpp"

using namespace std;

int amplada(BinaryTree<int> t, int cont){
    if(!t.isEmpty()){
        if(!t.getLeft().isEmpty()){
            cont++;
            cont = amplada(t.getLeft(), cont);
        }
        if(!t.getRight().isEmpty()){
            cont++;
            cont = amplada(t.getRight(), cont);
        }
    }
    return cont;
}

int sizeOfTree(BinaryTree<int> t){
    int cont = 1;
    cont =+ amplada(t, cont);
    return cont;
}