#include "maximumTree.hpp"
#include <cmath>

using namespace std;

typedef BinaryTree<int> BT;

// Pre: t1,t2 són dos arbres binaris d'enters positius.
// Post: t3 és un arbre, on a la seva arrel hi ha el màxim de les arrels de t1,t2,
// en l'arrel del fill esquerre hi ha el màxim de les arrels dels fills esquerre de t1,t2,
// en l'arrel del fill dret hi ha el màxim de les arrels dels fills drets de t1,t2,
// i així successivament.
// Quan un dels arbres no té valors definits en alguna posició, l'arbre resultant hi té
// el valor de l'altre arbre en aquella posició.
// Terminació: A cada nova crida recursiva, el nombre de nodes del nou t1 més el nombre de nodes
//             del nou t2 decreix.
void maximumTreeRec(const BinaryTree<int> &t1,const BinaryTree<int> &t2, BinaryTree<int> &t3)
{
    if (t1.isEmpty()) {
        t3 = t2;
        return;
    }
    if (t2.isEmpty()) {
        t3 = t1;
        return;
    }
    t3 = BT(max(t1.getRoot(),t2.getRoot()), BT(), BT());
    maximumTreeRec(t1.getLeft(),t2.getLeft(), t3.getLeft());
    // HI: cada posició p t3.getLeft conté el màxim dels valors
    //     de t1.getLeft() i t2.getLeft() a posició p.
    //     Si p és una posició definida a només un d'aquests dos arbres
    //     llavors hi tenim el valor de l'arbre a on està definit. Si p és una posició d'arbre
    //     buit a tots dos t1.getLeft(),t2.getLeft(), llavors també és una posició d'arbre buit
    //     a t3.getLeft(). Si p és una posició indefinida a tots dos t1.getLeft(),t2.getLeft(),
    //     llavors també és una posició indefinida a t3.getLeft().
    maximumTreeRec(t1.getRight(),t2.getRight(), t3.getRight());
    // HI: cada posició p t3.getRight conté el màxim dels valors
    //     de t1.getRight() i t2.getRight() a posició p.
    //     Si p és una posició definida a només un d'aquests dos arbres
    //     llavors hi tenim el valor de l'arbre a on està definit. Si p és una posició d'arbre
    //     buit a tots dos t1.getRight(),t2.getRight(), llavors també és una posició d'arbre buit
    //     a t3.getRight(). Si p és una posició indefinida a tots dos t1.getRight(),t2.getRight(),
    //     llavors també és una posició indefinida a t3.getRight().
}

// Pre: Rep dos arbres binaris d'enters positius t1 i t2.
// Post: Retorna un arbre, on a la seva arrel hi ha el màxim de les arrels de t1,t2,
// en l'arrel del fill esquerre hi ha el màxim de les arrels dels fills esquerre de t1,t2,
// en l'arrel del fill dret hi ha el màxim de les arrels dels fills drets de t1,t2,
// i així successivament.
// Quan un dels arbres no té valors definits en alguna posició, l'arbre resultant hi té
// el valor de l'altre arbre en aquella posició.
BinaryTree<int> maximumTree(BinaryTree<int> a1,BinaryTree<int> a2)
{
    BinaryTree<int> t3;
    maximumTreeRec(a1, a2, t3);
    return t3;
}