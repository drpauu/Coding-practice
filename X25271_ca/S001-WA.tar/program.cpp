#include "arbreBin.hpp"
#include <iostream>
using namespace std;

bool compleix_suma_fills(const arbreBin<int> &a){
    if(not a.es_buit()){
        int varrel = a.arrel();
        int vfe(0), vfd(0);
        if(!a.fe().es_buit()) {
            vfe = a.fe().arrel();
        }
        if(!a.fd().es_buit()) {
            vfe = a.fd().arrel();
        }
        if(varrel == vfe + vfd){
            return compleix_suma_fills(a.fe()) and compleix_suma_fills(a.fd());
        } else{
            return false;
        }
    } else{
        return true ;
    }
}

int main(void){
    arbreBin<int> a;
    cin>>a; 
    cout << a << endl;
    if(compleix_suma_fills(a)){
        cout << "L'arbre compleix la propietat 'Suma dels fills'." << endl;
    } else{
        cout << "L'arbre no compleix la propietat 'Suma dels fills'." << endl;
    }
}