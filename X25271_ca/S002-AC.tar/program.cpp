#include "arbreBin.hpp"
#include <iostream>
using namespace std;

bool compleix_suma_fills(const arbreBin<int> &a)
{
    bool compleix = true;
    if (!a.es_buit())
    {
        int varrel = a.arrel();
        int vfe = 0, vfd = 0;
        if (!a.fe().es_buit())
        {
            vfe = a.fe().arrel();
        }
        if (!a.fd().es_buit())
        {
            vfd = a.fd().arrel();
        }
        if (!a.fe().es_buit() or !a.fd().es_buit())
        {
            return (varrel == vfe + vfd) and compleix_suma_fills(a.fe()) and compleix_suma_fills(a.fd());
        }
    }
    return compleix;
}

int main(void)
{
    arbreBin<int> a;
    cin >> a;
    cout << a << endl;
    if (compleix_suma_fills(a))
    {
        cout << "L'arbre compleix la propietat 'Suma dels fills'." << endl;
    }
    else
    {
        cout << "L'arbre no compleix la propietat 'Suma dels fills'." << endl;
    }
}