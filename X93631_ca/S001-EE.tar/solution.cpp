#include "llista.hpp"
#include <iostream>

void Llista::fusiona_suma(Llista &l2, nat n){
    int suma = 0;
    node *aux1, *aux2, *ant;
    aux1 = _prim->seg;
    aux2 = l2._prim->seg;
    ant = nullptr;
    while(aux1 != nullptr or aux2 != nullptr){
        for(int i = 0; i < n; i++){
            if(aux1 == nullptr) break;
            suma += aux1->info;
            ant = aux1;
            aux1 = aux1->seg;
        }
        for(int i = 0; i < n; i++){
            if(aux2 == nullptr) break;
            if(_long == 0){
                suma += aux2->info;
                node *p;
                p = new node;
                p->info = aux2->info;
                p->seg = nullptr;
                _prim = nullptr;
                _prim->seg = p;
                ant = _prim->seg;
                aux1 = ant->seg;
                aux2 = aux2->seg;
                _long++;
            }else{
                suma += aux2->info;
                node *p;
                p = new node;
                p->info = aux2->info;
                p->seg = aux1;
                ant->seg = p;
                ant = ant->seg;
                aux2 = aux2->seg;
                _long++;
            }
        }
    }
    node *ft2;
    ft2 = new node;
    ft2->seg = nullptr;
    l2._prim = ft2;
    l2._long = 0;
    node *s;
    s = new node;
    s->info = suma;
    s->seg = _prim->seg;
    _prim = s;
    node *ft;
    ft = new node;
    ft->seg = _prim;
    _prim = ft;
    _long++;
}