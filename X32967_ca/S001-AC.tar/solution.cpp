#include "llista.hpp"

Llista::Llista(const vector<int> &v){
    _prim = nullptr;
    node *aux, *ft;
    ft = new node;
    ft->seg = ft;
    ft->ant = ft;
    _prim = ft;
    aux = _prim;
    for(int i = 0; i < v.size(); i++){
        node *valor;
        valor = new node;
        valor->info = v[i];
        valor->seg = _prim;
        valor->ant = aux;
        aux->seg = valor;
        aux = aux->seg;
        _prim->ant = aux;
    }
    _long = v.size();
};