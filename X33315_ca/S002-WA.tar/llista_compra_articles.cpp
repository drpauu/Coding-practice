#include "llista_compra_articles.hpp"
#include <iostream>
#include <list>

using namespace std;
void showlist(list<int> g) {
  list<int>::iterator it;
  for (it = g.begin(); it != g.end(); ++it)
    cout << '\t' << *it;
  cout << '\n';
}

int compra_articles(const list<int> &g, int x) {
  /* Pre: l = L, x > 0 */
  /* Post: El resultat es el nombre d'articles de L que podem comprar amb x
   * euros
   */
  int s = 0;
  list<int>::const_iterator it;
  for (it = g.begin(); it != g.end(); ++it) {
    if (*it < x) {
      s++;
      x = x - *it;
    }
  }
  return s;
}
