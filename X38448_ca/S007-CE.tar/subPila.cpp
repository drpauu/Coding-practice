#include "subPila.hpp"

using namespace std;

bool subPila(stack<int> p1, stack<int> p2) {
  if (p2.empty()) {
    return true;
  }
  if (!p1.empty()) {
    if (p1.top() != p2.top()) {
      p1.pop();
      subPila(p1, p2);
    } else if (p1.top() == p2.top()) {
      p1.pop();
      p2.pop();
      subPila(p1, p2);
    }
  } else
    return false;
}
