#include "subPila.hpp"

using namespace std;

bool subPila(stack<int> p1, stack<int> p2) {
  while (p1.top() != -1) {
    if (p1.top() == p2.top()) {
      while (p1.top() == p2.top()) {
        p1.pop();
        p2.pop();
      }
      if (p2.top() == -1) {
        return true;
      } else {
        return false;
      }
    } else {
      p1.pop();
    }
  }
  return subPila(p1, p2);
}
