#include "subPila.hpp"

using namespace std;

bool subPila(stack<int> p1, stack<int> p2) {
  bool tr = false;
  int aux;
  if (p1.top() == p2.top()) {
    aux = p2.top();
    p1.pop();
    p2.pop();
    if (p2.empty()) {
      return true;
      tr = true;
    } else {
      p2.push(aux);
      subPila(p1, p2);
    }
  } else {
    p1.pop();
    if (p1.empty()) {
      return false;
      tr = false;
    } else {
      subPila(p1, p2);
    }
  }
  return tr;
}
