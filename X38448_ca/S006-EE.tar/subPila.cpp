#include "subPila.hpp"

using namespace std;

/*bool subPila(stack<int> p1, stack<int> p2) {
  stack<int> aux = p2;
  if (p1.size() < p2.size()) {
    return false;
  } else {
    if (p1.top() == p2.top()) {
      p1.pop();
      p2.pop();
      if (p2.empty()) {
        return true;
      } else {
        subPila(p1, p2);
      }
    } else {
      p1.pop();
      if (p1.empty()) {
      } else {
        subPila(p1, aux);
      }
    }
  }
}
*/
int cont = -1;
stack<int> aux;
bool ret = false;

bool subPila(stack<int> p1, stack<int> p2) {
  if (cont == -1)
    aux = p2;
  if (ret)
    return true;
  if (p1.size() < p2.size())
    return false;
  else if (!p1.empty() || !p2.empty()) {
    if (p1.top() != p2.top()) {
      p1.pop();
      cont = 0;
      subPila(p1, aux);
    } else {
      cont++;
      if (cont == aux.size())
        ret = true;
      p1.pop();
      p2.pop();
      subPila(p1, p2);
    }
  }
  return ret;
}
