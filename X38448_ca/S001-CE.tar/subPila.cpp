#include "subPila.hpp"

using namespace std;

bool subPila(stack<int> p1, stack<int> p2) {
  if (p1.top() != p2.top()) {
    p1.pop();
  }
  if (p1.top() == -1) {
    return false;
  }
  if (p1.top() == p2.top()) {
    p2.pop();
    p1.pop();
    if (p1.top() != p2.top()) {
      return false;
    } else {
      return subPila(p1, p2);
    }
  }
}
