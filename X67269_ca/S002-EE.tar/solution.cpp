#include "llista.hpp"
#include <iostream>

void Llista::fusiona_suma(Llista &l2, nat n){
    int suma = 0;
    node *aux1, *aux2, *ant;
    aux1 = _prim;
    aux2 = l2._prim;
    ant = nullptr;
    while(aux1 != nullptr or aux2 != nullptr){
        for(int i = 0; i < n; i++){
            if(aux1 == nullptr) break;
            suma += aux1->info;
            ant = aux1;
            aux1 = aux1->seg;
        }
        for(int i = 0; i < n; i++){
            if(aux2 == nullptr) break;
            suma += aux2->info;
            node *p;
            p = new node;
            p->info = aux2->info;
            p->seg = aux1;
            ant->seg = p;
            ant = ant->seg;
            aux2 = aux2->seg;
            _long++;
        }
    }
    l2._prim = nullptr;
    l2._long = 0;
    node *s;
    s = new node;
    s->info = suma;
    s->seg = _prim;
    _prim = s;
    _long++;
}
/*aquest programa fica n elements del pi, n de l2 i dsp els interseccion

void Llista::fusiona_suma(Llista &l2, nat n){
    int suma = 0;
    node *aux1, *aux2;
    aux1 = _prim;
    aux2 = l2._prim;
    int i = 0;
    node *ant;
    ant = nullptr;
    while(i < n and aux1 != nullptr){
        suma += aux1->info;
        ant = aux1;
        aux1 = aux1->seg;
        i++;
    }
    int j = 0;
    while(j < n and aux2 != nullptr){
        suma += aux2->info;
        node *p;
        p = new node;
        p->info = aux2->info;
        p->seg = aux1;
        ant->seg = p;
        ant = ant->seg;
        aux2 = aux2->seg;
        _long++;
        j++;
    }
    int par = 0;
    if(aux1 == nullptr) {
        l2._prim = nullptr;
        l2._long = 0;
        node *s;
        s = new node;
        s->info = suma;
        s->seg = _prim;
        _prim = s;
        _long++;
        return;
    }
    suma += aux1->info;
    ant = aux1;
    aux1 = aux1->seg;
    while(aux2 != nullptr or aux1 != nullptr){
        if(par%2 == 0 and aux2 != nullptr){
            suma += aux2->info;
            node *p;
            p = new node;
            p->info = aux2->info;
            p->seg = aux1;
            ant->seg = p;
            ant = ant->seg;
            aux2 = aux2->seg;
            _long++;

        } else{
            suma += aux1->info;
            ant = aux1;
            aux1 = aux1->seg;
        }
        par++;
    }
    l2._prim = nullptr;
    l2._long = 0;
    node *s;
    s = new node;
    s->info = suma;
    s->seg = _prim;
    _prim = s;
    _long++;
}
*/