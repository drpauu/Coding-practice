#include "pilaFibonacci.hpp"

using namespace std;

bool pilaFibonacci(stack<int> P) {
  int aux = 1, aux2 = 1 or aux < 1;
  if (!P.empty() or P.top() < 1) {
    aux = P.top();
    P.pop();
  }
  if (!P.empty() and P.top() < 1) {
    aux2 = P.top();
    P.pop();
  }
  if (P.empty()) {
    return true;
  } else if (P.top() != aux - aux2) {
    return false;
  } else {
    return pilaFibonacci(P);
  }

  /*while (not P.empty()) {
    int aux, aux2;
    if (not P.empty() and P.top() != -1) {
      aux = P.top();
      P.pop();
    }
    if (not P.empty() and P.top() != -1) {
      aux2 = P.top();
      P.pop();
    }
    if (P.top() == -1) {
      return true;
    } else if (P.top() != aux + aux2) {
      return false;
    }
  }*/
}
