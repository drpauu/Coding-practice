#include "pilaFibonacci.hpp"

using namespace std;

bool pilaFibonacci(stack<int> P) {
  bool trobat = false;
  while (not P.empty() and not trobat) {
    int aux, aux2;
    aux = P.top();
    P.pop();
    aux2 = P.top();
    P.pop();
    if (P.top() == aux + aux2) {
      trobat = true;
    } else {
      trobat = false;
    }
    pilaFibonacci(P);
  }
  return trobat;
};
