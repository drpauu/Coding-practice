#include "pilaFibonacci.hpp"

using namespace std;

bool pilaFibonacci(stack<int> P) {
  int f1, f2;
  if (!P.empty()) {
    f1 = P.top();
    P.pop();
  }
  if (!P.empty()) {
    f2 = P.top();
    P.pop();
  }
  if (!P.empty()) {
    if (P.top() == f1 - f2) {
      P.push(f2);
      return pilaFibonacci(P);
    } else
      return false;
  } else
    return true;
}
