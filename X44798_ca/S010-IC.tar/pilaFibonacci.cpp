#include "pilaFibonacci.hpp"

using namespace std;

bool pilaFibonacci(stack<int> P) {
  int aux = 0, aux2 = 0;
  if (!P.empty()) {
    aux = P.top();
    P.pop();
  }
  if (!P.empty()) {
    aux2 = P.top();
    P.pop();
  }
  if (P.empty()) {
    return true;
  } else if (P.top() != aux - aux2) {
    return false;
  } else {
    return pilaFibonacci(P);
  }
}
