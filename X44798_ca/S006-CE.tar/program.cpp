#include "pilaFibonacci.hpp"
#include "utilitats.hpp"

int main() {
  stack<int> P;

  llegeix(P);
  stack<int> I = P;
  escriu(P);

  bool b = pilaFibonacci(P);
  cout << (b ? "sí" : "no") << endl;

  return 0;
}
