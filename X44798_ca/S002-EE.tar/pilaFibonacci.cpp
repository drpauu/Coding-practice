#include "pilaFibonacci.hpp"

using namespace std;

bool pilaFibonacci(stack<int> P) {
  bool trobat = true;
  while (not P.empty() and trobat) {
    int aux, aux2;
    aux = P.top();
    P.pop();
    aux2 = P.top();
    P.pop();
    if (P.top() == aux + aux2) {
      trobat = true;
    } else {
      trobat = false;
    }
    pilaFibonacci(P);
  }
  return trobat;
};
