#include "searchInBST.hpp"

using namespace std;

bool valid(BinaryTree<int> &t, int x){
        if(t.isEmpty()) return false;
    if(t.getRoot() == x ) {
        return true;
    } else return valid(t.getRight(), x) or valid(t.getLeft(), x);
}

bool searchInBST(BinaryTree<int> &t, int x){
    return valid(t, x);
}