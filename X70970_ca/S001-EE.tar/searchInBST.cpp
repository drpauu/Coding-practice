#include "searchInBST.hpp"

using namespace std;

bool searchInBST(BinaryTree<int> &t, int x){
    if(t.isEmpty()) return false;
    if(t.getRoot() == x ) {
        return true;
    } else return searchInBST(t.getRight(), x) or searchInBST(t.getLeft(), x);

}