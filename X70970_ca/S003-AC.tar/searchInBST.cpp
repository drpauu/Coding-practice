#include "searchInBST.hpp"

using namespace std;

bool searchInBST(BinaryTree<int> &t, int x){
    if(t.isEmpty()) return false;
    if(t.getRoot() == x ) {
        return true;
    } else {
        if(t.getRoot() < x ){
            return searchInBST(t.getRight(), x);
        } else return searchInBST(t.getLeft(), x);
    }
}