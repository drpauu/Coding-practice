#include "treeOfSums.hpp"

using namespace std;

typedef BinaryTree<int> BT;

int suma(BinaryTree<int> &t, int sum){
    if(t.getLeft().isEmpty() and t.getRight().isEmpty()) {
        return t.getRoot();
    } else if(t.getRight().isEmpty()){
        sum += suma(t.getLeft(), sum) + t.getRoot();
        return sum;
    }else if(t.getLeft().isEmpty()){
        sum += suma(t.getRight(), sum) + t.getRoot();
        return sum;
    } else {
        sum += suma(t.getLeft(), sum) + suma(t.getRight(), sum) + t.getRoot();
        return sum;
    }
}

BT sumat(BT &t, BT &s){
    int sum = 0;
    if(t.isEmpty()) return s;
    s = BT(suma(t, sum), BT(), BT());
    if(!t.getLeft().isEmpty()) s.getLeft() = sumat(t.getLeft(), s.getLeft());
    if(!t.getRight().isEmpty()) s.getRight() = sumat(t.getRight(), s.getRight());
    return s;
}

BinaryTree<int> treeOfSums(BinaryTree<int> t){
    BinaryTree<int> s;
    return sumat(t, s);
}