#include "llista.hpp"

Llista::Llista(const vector<int> &v){
    _prim = nullptr;
    node *aux;
    aux = nullptr;
    for(int i = 0; i < v.size(); i++){
        if(_prim == nullptr){
            node *valor;
            valor = new node;
            valor->info = v[i];
            valor->seg = nullptr;
            _prim = valor;
            aux = _prim;
        } else {
            node *valor;
            valor = new node;
            valor->info = v[i];
            valor->seg = nullptr;
            aux->seg = valor;
            aux = aux->seg;
        }
    }
    _long = v.size();
};