#include "llista.hpp"
#include <iostream>

void Llista::fusiona_suma(Llista &l2, nat n)
{
    unsigned int suma = 0;
    node *aux1, *aux2, *ant;
    aux1 = _prim->seg;
    aux2 = l2._prim->seg;
    ant = nullptr;
    int bucle = _long + l2._long;
    int b1 = 0, b2 = 0;
    for (int i = 0; i < bucle; i++)
    {
        for (int i = 0; i < n; i++)
        {
            if (b1 == bucle)
            {
                break;
            }
            ant = aux1;
            aux1 = aux1->seg;
            b1++;
        }
        for (int i = 0; i < n; i++)
        {
            if (b2 == l2._long)
            {
                break;
            }
            if (_long == 0)
            {
                node *p;
                p = new node;
                p->info = aux2->info;
                p->seg = aux1;
                ant->seg = p;
                ant = ant->seg;
                aux2 = aux2->seg;
                _long++;
                b2++;
            }
            else
            {
                node *p;
                p = new node;
                p->info = aux2->info;
                p->seg = aux1;
                ant->seg = p;
                ant = ant->seg;
                aux2 = aux2->seg;
                _long++;
                b2++;
            }
        }
    }
    node *ft2;
    ft2 = new node;
    ft2->seg = ft2;
    l2._prim = ft2;
    l2._long = 0;
    node *p = _prim->seg;
    while (p != _prim) {
        suma += p->info;
    p = p->seg;
    }
    node *p1;
    p1 = new node;
    p1->info = suma;
    p1->seg = _prim->seg;
    _prim->seg = p1;
    _long++;
}
