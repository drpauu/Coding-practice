#include "cua.hpp"

cua::cua(const vector<int> &v){
    _ult = nullptr;
    for(int i = 0; i < v.size(); i++){
        node *aux;
        aux = nullptr;
        if(_ult == nullptr){
            node *valor;
            valor = new node;
            valor->info = v[i];
            _ult = valor;
            _ult->seg = _ult;
        } else {
            node *valor;
            valor = new node;
            valor->info = v[i];
            aux = _ult;
            valor->seg = _ult->seg;
            _ult = valor;
            aux->seg = _ult;
        }
    }
    _long = v.size();
};