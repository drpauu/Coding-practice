#include "maxOfTree.hpp"

using namespace std;

int max(BinaryTree<int> &t, int cont){
    if(!t.isEmpty()){
        if(!t.getLeft().isEmpty()){
            if(t.getLeft().getRoot() >= cont){
                cont = t.getLeft().getRoot();
            }
            cont = max(t.getLeft(), cont);
        }
        if(!t.getRight().isEmpty()){
            if(t.getRight().getRoot() >= cont){
                cont = t.getRight().getRoot();
            }
            cont = max(t.getRight(), cont);
        }
    }
    return cont;
}

int maxOfTree(BinaryTree<int> t){
    int cont = t.getRoot();
    cont = max(t, cont);
    return cont;
}