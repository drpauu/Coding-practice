#include "heightOfTree.hpp"

using namespace std;

int altura(BinaryTree<int> t, int cont){
    if(!t.isEmpty()){
        if(!t.getLeft().isEmpty() or !t.getRight().isEmpty()){
            cont++;
            if(!t.getRight().isEmpty() and !t.getLeft().isEmpty()){
                if(altura(t.getRight(), cont) > altura(t.getLeft(), cont)){
                    cont =+ altura(t.getRight(), cont);
                } else {
                    cont =+ altura(t.getLeft(), cont);
                }
            } else if(!t.getRight().isEmpty()){
                cont =+ altura(t.getRight(), cont);
            } else if(!t.getLeft().isEmpty()){
                cont =+ altura(t.getLeft(), cont);
            }
        }
    }
    return cont;
}

int heightOfTree(BinaryTree<int> t){
    int cont = 1;
    cont =+ altura(t, cont);
    return cont;
}