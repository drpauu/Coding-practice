#include "abin.hpp"
#include <iostream>

template <typename T>
list<T> Abin<T>::preordre() const
{
    bool acabat = false;
    node *m = _arrel;
    list<T> l;
    while (not acabat)
    {
        if (m == nullptr)
            acabat = true;
        else if (m->f_esq != nullptr and not m->thread_esq)
        {
            l.push_back(m->info);
            m = m->f_esq;
        }
        else if (m->f_dret != nullptr and not m->thread_dret)
        {
            l.push_back(m->info);
            m = m->f_dret;
        }
        else
        {
            l.push_back(m->info);
            while (m->thread_dret and not acabat)
            {
                if (m->f_dret == nullptr)
                {
                    acabat = true;
                }
                else
                    m = m->f_dret;
            }
            m = m->f_dret;
        }
    }
    return l;
}
