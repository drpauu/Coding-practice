#include "esborraSenars.hpp"

using namespace std;

void esborraSenars(stack<int> &a) {
  stack<int> b;
  while (!a.empty()) {
    if (a.top() % 2 == 0) {
      b.push(a.top());
    }
    a.pop();
  }
  while (!b.empty()) {
    a.push(b.top());
    b.pop();
  }
}
