#include "stackIOpunt.hpp"

bool cerca(stack<Punt> p, Punt x){
    bool trobat=false;
    
    while(not trobat and not p.empty()){
        if(x==p.top()){
            trobat=true;
        }
        else p.pop();
    }
    return trobat;
}

int main(){
    stack<Punt> p;
    cin>>p;
    Punt x;
    cout<<p;
    while(cin>>x){
        bool r;
        r=cerca(p, x);
        if(r)cout<<"El punt "<<x<<" es troba en la pila."<<endl;
        else cout<<"El punt "<<x<<" no es troba en la pila."<<endl;
    }
}