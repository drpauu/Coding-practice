#include "llista.hpp"

Llista::Llista(const vector<int> &v){
    _prim = nullptr;
    node *aux, *ft;
    ft = new node;
    ft->seg = nullptr;
    _prim = ft;
    aux = _prim;
    for(int i = 0; i < v.size(); i++){
        node *valor;
        valor = new node;
        valor->info = v[i];
        valor->seg = nullptr;
        aux->seg = valor;
        aux = aux->seg;
    }
    _long = v.size()+1;
};