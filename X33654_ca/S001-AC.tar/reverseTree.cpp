#include "BinaryTree.hpp"

using namespace std;

typedef BinaryTree<int> BT;

void reverseTreeRec(BT &t, BT &r){
    if(t.isEmpty()) return;
    r = BT(t.getRoot(), BT(), BT());
    reverseTreeRec(t.getRight(), r.getLeft());
    reverseTreeRec(t.getLeft(), r.getRight());
}

BT reverseTree(BT f){
    BT r;
    reverseTreeRec(f, r);
    return r;
}