#include "sumOfTree.hpp"

using namespace std;

int contador(BinaryTree <int> &t){
    if (t.isEmpty()) return 0;
    return t.getRoot()+contador(t.getLeft())+contador(t.getRight());
}

int sumOfTree(BinaryTree<int> t){
    return contador(t);
}