#include "sumOfTree.hpp"

using namespace std;

int function(BinaryTree<int> t, int cont){
    if(!t.isEmpty()){
        cont = cont + t.getRoot();
        if(!t.getLeft().isEmpty()){
            cont += function(t.getLeft(), cont); 
        }
        if(!t.getRight().isEmpty()){
            cont += function(t.getRight(), cont);
        }
    } 
    return cont; 
}

int sumOfTree(BinaryTree<int> t){
    int cont = 0;
    cont = function(t, cont);
    return cont; 
}