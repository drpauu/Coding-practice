#include "sumOfTree.hpp"

using namespace std;

int contador(BinaryTree <int> t, int cont){
    int aux;
    if(!t.isEmpty()){
        aux = cont;
        cont = aux + t.getRoot();
        if(!t.getLeft().isEmpty()){
            aux = cont;
            cont =+ contador(t.getLeft(), aux);
        }
        if(!t.getRight().isEmpty()){
            aux = cont;
            cont =+ contador(t.getRight(), aux);
        }
    }
    return cont;
}

int sumOfTree(BinaryTree<int> t){
    int cont = 0;
    cont =+ contador(t, cont);
    return cont;
}