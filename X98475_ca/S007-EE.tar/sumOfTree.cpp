#include "sumOfTree.hpp"

using namespace std;

void contador(BinaryTree <int> t, int cont){
    int aux;
    if(!t.isEmpty()){
        aux = cont;
        cont = aux + t.getRoot();
        if(!t.getLeft().isEmpty()){
            aux = cont;
            contador(t.getLeft(), aux);
        }
        if(!t.getRight().isEmpty()){
            aux = cont;
            contador(t.getRight(), aux);
        }
    }
}

int sumOfTree(BinaryTree<int> t){
    int cont = 0;
    contador(t, cont);
    return cont;
}