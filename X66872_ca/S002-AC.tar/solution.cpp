#include "llista.hpp"
#include <iostream>

void Llista::separa(Llista &l2){
    l2._prim = nullptr;
    node *aux1, *ant, *aux2;
    aux1 = _prim;
    ant = nullptr;
    aux2 = l2._prim;
    int i = 0;
    while(aux1 != nullptr){
        if(i%2 != 0){
            if(l2._long == 0){
                node *nou;
                nou = new node;
                nou->seg = nullptr;
                nou->info = aux1->info;
                l2._prim = nou;
                aux2 = l2._prim;
                l2._long++;
                if(aux1 == _prim){
                    _prim = _prim->seg;
                    aux1 = _prim;
                    _long--;
                } else {
                    ant->seg = aux1->seg;
                    _long--;
                    aux1 = aux1->seg;
                }
            } else {
                node *nou;
                nou = new node;
                nou->seg = nullptr;
                nou->info = aux1->info;
                aux2->seg = nou;
                aux2 = aux2->seg;
                l2._long++;
                if(aux1 == _prim){
                    _prim = _prim->seg;
                    aux1 = _prim;
                    _long--;
                } else {
                    ant->seg = aux1->seg;
                    _long--;
                    aux1 = aux1->seg;
                }
            }
        } else{
            ant = aux1;
            aux1 = aux1->seg;
        }
        i++;
    }
}
