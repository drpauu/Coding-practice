#include "llista.hpp"

void Llista::separa(Llista &l2){
    node *aux, *ant;
    ant = nullptr;
    aux = _prim;
    l2._prim = nullptr;
    l2._long = 0;
    node *p;
    p = l2._prim;
    for(int i = 0; i > _long; i++){
        if(aux->info%2 != 0){
            if(aux == _prim and p == l2._prim){
                node *del, *nou;
                nou = new node;
                nou = aux;
                nou->seg = nullptr;
                l2._prim = nou;
                p = l2._prim;
                del = _prim;
                aux = aux->seg;
                _prim = aux;
                delete del;
            } else if(aux == _prim){
                node *del, *nou;
                nou = new node;
                nou = aux;
                nou->seg = nullptr;
                p->seg = nou;
                p = p->seg;
                aux = aux->seg;
                del = _prim;
                _prim = aux;
                delete del;
            } else if(p == l2._prim){
                node *del, *nou;
                nou = new node;
                nou = aux;
                nou->seg = nullptr;
                l2._prim = nou;
                p = l2._prim;
                del = aux;
                ant->seg = aux;
                aux = aux->seg;
                delete del;
            }
        } else {
            ant = aux;
            aux = aux->seg;
        }
    }
}