#include "arbreBin.hpp"
#include <iostream>
using namespace std;

int suma(int s, const arbreBin<int> &a)
{
    if (a.es_buit())
        return s;
    else
    {
        if (!a.fe().es_buit() && !a.fd().es_buit())
        {
            s = a.arrel() + suma(s, a.fe()) + suma(s, a.fd());
        }
        else if (!a.fe().es_buit())
        {
            s = a.arrel() + suma(s, a.fe());
        }
        else if (!a.fd().es_buit())
        {
            s = a.arrel() + suma(s, a.fd());
        }
        else
        {
            return a.arrel();
        }
    }
    return s;
}

arbreBin<int> asumes(const arbreBin<int> &a, int valor)
{
    if (!a.es_buit())
    {
        valor = 0;
        if (!a.fe().es_buit() && !a.fd().es_buit())
        {
            valor = suma(valor, a);
            arbreBin<int> b(valor, asumes(a.fe(), valor), asumes(a.fd(), valor));
            return b;
        }
        else if (!a.fe().es_buit())
        {
            valor = suma(valor, a);
            arbreBin<int> b(valor, asumes(a.fe(), valor), arbreBin<int>());
            return b;
        }
        else if (!a.fd().es_buit())
        {
            valor = suma(valor, a);
            arbreBin<int> b(valor, arbreBin<int>(), asumes(a.fd(), valor));
            return b;
        }
        else
        {
            valor = a.arrel();
            arbreBin<int> b(valor, arbreBin<int>(), arbreBin<int>());
            return b;
        }
    }
    else
    {
        return arbreBin<int>();
    }
}

int main(void)
{
    arbreBin<int> a;
    cin >> a;
    int valor = 0;
    cout << asumes(a, valor) << endl;
}