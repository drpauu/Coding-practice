#include "arbreBin.hpp"
#include <iostream>
using namespace std;

/*
template <typename T>
arbreBin<int> asumes(arbreBin<T> a, int valor)
{
    int valor;
    if(!a.es_buit()){
        if(!a.fe().es_buit() && !a.fd().es_buit()){
            valor = a.arrel() + asumes(a.fe(), valor) + asumes(a.fd(), valor);
            arbreBin<T> b(valor, a.fe(), a.fd());
            cout << b << endl;
            return b;
        } else if(!a.fe().es_buit()){
            valor = a.arrel() + asumes(a.fe(), valor);
            arbreBin<T> b(valor, a.fe(), arbreBin<T>());
            return b;
        } else if(!a.fd().es_buit()){
            valor = a.arrel() + asumes(a.fd(), valor);
            arbreBin<T> b(valor, arbreBin<T>(), a.fd());
            return b;
        } else {
            arbreBin<T> b(a.arrel(), arbreBin<T>(), arbreBin<T>());
            return b;
        }
    } else {
        arbreBin<int> ret();
        return ret;
    }
}*/

int suma(int s, arbreBin<int> a)
{
    if (a.es_buit())
        return s;
    else
    {
        if (!a.fe().es_buit() && !a.fd().es_buit())
        {
            s = a.arrel() + suma(s, a.fe()) + suma(s, a.fd());
        }
        else if (!a.fe().es_buit())
        {
            s = a.arrel() + suma(s, a.fe());
        }
        else if (!a.fd().es_buit())
        {
            s = a.arrel() + suma(s, a.fd());
        }
        else
        {
            return a.arrel();
        }
    }
    return s;
}

arbreBin<int> asumes(arbreBin<int> a, int valor)
{
    if (!a.es_buit())
    {
        valor = 0;
        if (!a.fe().es_buit() && !a.fd().es_buit())
        {
            valor = suma(valor, a);
            arbreBin<int> b(valor, asumes(a.fe(), valor), asumes(a.fd(), valor));
            return b;
        }
        else if (!a.fe().es_buit())
        {
            valor = suma(valor, a);
            arbreBin<int> b(valor, asumes(a.fe(), valor), arbreBin<int>());
            return b;
        }
        else if (!a.fd().es_buit())
        {
            valor = suma(valor, a);
            arbreBin<int> b(valor, arbreBin<int>(), asumes(a.fd(), valor));
            return b;
        }
        else
        {
            valor = a.arrel();
            arbreBin<int> b(valor, arbreBin<int>(), arbreBin<int>());
            return b;
        }
    }
    else
    {
        return arbreBin<int>();
    }
}

int main(void)
{
    arbreBin<int> a, b;
    cin >> a;
    int valor = 0;
    b = asumes(a, valor);
    cout << b << endl;
}