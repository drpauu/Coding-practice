#include "arbreBin.hpp"
#include <iostream>
using namespace std;

arbreBin<int> asumes(arbreBin<int> a)
{
    int vfd, vfe, arrel;
    if(a.es_buit()) return a;
    arbreBin<int> filld, fille;
    filld = asumes(a.fd());
    fille = asumes(a.fe());
    if(a.fd().es_buit())  vfd = 0;
    else  vfd = filld.arrel();
    if(a.fe().es_buit())  vfe = 0;
    else  vfe = fille.arrel();
    arrel = a.arrel() + vfe + vfd;
    return arbreBin<int>(arrel, fille, filld);
}

int main(void)
{
    arbreBin<int> a;
    cin >> a;
    cout << asumes(a) << endl;
}